import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { Transaction, TransactionInput } from './models/transaction';
import { TransactionService } from './services/transaction.service';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './dashboard.html',
})
export class App implements OnInit {
  transactions: Transaction[] = [];
  selectedType = 'all';
  selectedCategory = 'all';
  editingId: string | null = null;
  errorMessage = '';
  successMessage = '';

  categories = [
    'Salário',
    'Freelance',
    'Investimentos',
    'Alimentação',
    'Moradia',
    'Transporte',
    'Saúde',
    'Educação',
    'Lazer',
    'Outros',
  ];

  form: TransactionInput = this.createEmptyForm();

  constructor(private transactionService: TransactionService) {}

  get filteredTransactions(): Transaction[] {
    const filtered: Transaction[] = [];

    for (const transaction of this.transactions) {
      const matchesType =
        this.selectedType === 'all' || transaction.type === this.selectedType;
      const matchesCategory =
        this.selectedCategory === 'all' || transaction.category === this.selectedCategory;

      if (matchesType && matchesCategory) {
        filtered.push(transaction);
      }
    }

    return filtered;
  }

  get incomeTotal(): number {
    let total = 0;

    for (const transaction of this.transactions) {
      if (transaction.type === 'income') {
        total += transaction.amount;
      }
    }

    return total;
  }

  get expenseTotal(): number {
    let total = 0;

    for (const transaction of this.transactions) {
      if (transaction.type === 'expense') {
        total += transaction.amount;
      }
    }

    return total;
  }

  get balance(): number {
    return this.incomeTotal - this.expenseTotal;
  }

  ngOnInit(): void {
    this.loadTransactions();
  }

  loadTransactions(): void {
    this.errorMessage = '';
    this.transactionService.getAll().subscribe({
      next: (transactions) => {
        this.transactions = transactions;
      },
      error: () => {
        this.errorMessage = 'Não foi possível carregar as movimentações. Verifique a API e o MongoDB.';
      },
    });
  }

  submitForm(): void {
    this.errorMessage = '';
    this.successMessage = '';

    let request: Observable<Transaction>;

    if (this.editingId) {
      request = this.transactionService.update(this.editingId, this.form);
    } else {
      request = this.transactionService.create(this.form);
    }

    request.subscribe({
      next: () => {
        if (this.editingId) {
          this.successMessage = 'Movimentação atualizada.';
        } else {
          this.successMessage = 'Movimentação cadastrada.';
        }

        this.cancelEdit();
        this.loadTransactions();
      },
      error: (error: HttpErrorResponse) => {
        this.errorMessage =
          error.error?.message || 'Não foi possível salvar a movimentação.';
      },
    });
  }

  editTransaction(transaction: Transaction): void {
    this.editingId = transaction._id;
    this.form = {
      description: transaction.description,
      type: transaction.type,
      category: transaction.category,
      amount: transaction.amount,
      date: transaction.date.slice(0, 10),
    };
    this.successMessage = '';
    this.errorMessage = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  deleteTransaction(transaction: Transaction): void {
    if (!window.confirm(`Excluir "${transaction.description}"?`)) {
      return;
    }

    this.transactionService.delete(transaction._id).subscribe({
      next: () => {
        this.successMessage = 'Movimentação excluída.';
        this.loadTransactions();
      },
      error: () => {
        this.errorMessage = 'Não foi possível excluir a movimentação.';
      },
    });
  }

  cancelEdit(): void {
    this.editingId = null;
    this.form = this.createEmptyForm();
  }

  setType(type: string): void {
    this.selectedType = type;
  }

  setCategory(category: string): void {
    this.selectedCategory = category;
  }

  categoryClass(category: string): string {
    const categoryIndex = this.categories.indexOf(category);
    return `category-tag category-color-${Math.max(categoryIndex, 0) % 5}`;
  }

  private createEmptyForm(): TransactionInput {
    const today = new Date();
    const localDate = [
      today.getFullYear(),
      String(today.getMonth() + 1).padStart(2, '0'),
      String(today.getDate()).padStart(2, '0'),
    ].join('-');

    return {
      description: '',
      type: 'expense',
      category: '',
      amount: 0,
      date: localDate,
    };
  }
}
