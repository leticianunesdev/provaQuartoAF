import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { App } from './app';
import { appConfig } from './app.config';
import { TransactionService } from './services/transaction.service';

const transactions = [
  {
    _id: 'income-1',
    description: 'Salário',
    type: 'income' as const,
    category: 'Salário',
    amount: 100,
    date: '2025-01-03T00:00:00.000Z',
  },
  {
    _id: 'expense-1',
    description: 'Mercado',
    type: 'expense' as const,
    category: 'Alimentação',
    amount: 25,
    date: '2025-01-04T00:00:00.000Z',
  },
];

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [
        ...appConfig.providers,
        {
          provide: TransactionService,
          useValue: { getAll: () => of(transactions) },
        },
      ],
    })
      .compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render the finance dashboard', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Seu dinheiro');
  });

  it('should calculate the balance and filter by category', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();

    expect(fixture.componentInstance.balance).toBe(75);
    fixture.componentInstance.setCategory('Alimentação');
    expect(fixture.componentInstance.filteredTransactions).toHaveLength(1);
    expect(fixture.componentInstance.filteredTransactions[0].description).toBe('Mercado');
  });
});
