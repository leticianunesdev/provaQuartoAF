export type TransactionType = 'income' | 'expense';

export interface Transaction {
  _id: string;
  description: string;
  type: TransactionType;
  category: string;
  amount: number;
  date: string;
}

export interface TransactionInput {
  description: string;
  type: TransactionType;
  category: string;
  amount: number;
  date: string;
}
