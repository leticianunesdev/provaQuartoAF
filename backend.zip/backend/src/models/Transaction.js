const mongoose = require('mongoose');

const esquemaMovimentacao = new mongoose.Schema(
  {
    description: {
      type: String,
      required: [true, 'A descrição é obrigatória.'],
      trim: true,
      maxlength: [100, 'A descrição deve ter no máximo 100 caracteres.'],
    },
    type: {
      type: String,
      required: true,
      enum: ['income', 'expense'],
    },
    category: {
      type: String,
      required: [true, 'A categoria é obrigatória.'],
      trim: true,
    },
    amount: {
      type: Number,
      required: [true, 'O valor é obrigatório.'],
      min: [0.01, 'O valor deve ser maior que zero.'],
    },
    date: {
      type: Date,
      required: [true, 'A data é obrigatória.'],
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model('Transaction', esquemaMovimentacao);
