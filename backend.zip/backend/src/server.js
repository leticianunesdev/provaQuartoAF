require('dotenv').config();

const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');
const transactionRoutes = require('./routes/transactions');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.use('/api/transactions', transactionRoutes);

app.use((error, req, res, next) => {
  if (error.name === 'ValidationError' || error.name === 'CastError' || error instanceof SyntaxError) {
    return res.status(400).json({ message: error.message });
  }

  console.error(error);
  res.status(500).json({ message: 'Erro interno do servidor.' });
});

async function startServer() {
  if (!process.env.MONGODB_URI) {
    throw new Error('MONGODB_URI não definida. Abra backend/.env e cole a URI do MongoDB Atlas.');
  }

  await mongoose.connect(process.env.MONGODB_URI);
  app.listen(port, () => {
    console.log(`API disponível em http://localhost:${port}`);
  });
}

startServer().catch((error) => {
  console.error('Não foi possível iniciar a API:', error.message);
  process.exit(1);
});
